package com.ssun.everybook.controller;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssun.everybook.service.BookService;

@RequestMapping("/bookbook/*")
@Controller
public class BookController {

	private static final Logger logger = LoggerFactory.getLogger(BookController.class);

	@Inject
	private BookService service;

	@RequestMapping(value = "/book", method = RequestMethod.GET)
	public String search(HttpServletRequest request,
			@RequestParam(value = "queryWord", required = false, defaultValue = "") String queryWord) throws Exception {
		logger.info("searchList get .............");

		String addResult = service.aladinBookApi(queryWord);
		System.out.println("queryWord" + queryWord);

		ArrayList<String> test = new ArrayList<String>();
		ArrayList<String> error = new ArrayList<String>();

		test = service.aladinCrawler(queryWord);
		// aladin 처리 끝
		
		
		// yes 24 시작
		String aa = null;
		aa = service.yes24Crawler(queryWord);
		System.out.println("================yes24======CONTROLLER START========\n");

		request.setAttribute("hash",aa);
		System.out.println(aa);
		System.out.println("================yes24======CONTROLLER END========\n");
		
		
		// api 오류
		if (addResult.contains("오류")) {
			error.add("error");
			request.setAttribute("test", error);
			System.out.println("Testtttttttttttttttttttttttttt000" + error);
			request.setAttribute("addResult", error);
		} else {
			request.setAttribute("test", test);
			request.setAttribute("addResult", addResult);
		}

		request.setAttribute("queryWord", queryWord);

		return "book";

	}

}
