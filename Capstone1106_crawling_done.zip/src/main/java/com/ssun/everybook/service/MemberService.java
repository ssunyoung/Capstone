package com.ssun.everybook.service;

import com.ssun.everybook.domain.MemberVO;

public interface MemberService {

	public void regist(MemberVO board) throws Exception;

}
