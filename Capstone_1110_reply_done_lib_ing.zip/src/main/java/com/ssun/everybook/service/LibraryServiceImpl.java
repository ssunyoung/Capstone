package com.ssun.everybook.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Repository;

import com.ssun.everybook.domain.LibraryInput;
import com.ssun.everybook.domain.LibraryVO;
import com.ssun.everybook.persistence.LibraryDAO;

@Repository
public class LibraryServiceImpl implements LibraryService {

	@Inject
	private LibraryDAO dao;

	@Override
	public List<LibraryVO> listLibrary(LibraryInput libInput) throws Exception {
		System.out.println("SERVICE____________libInput"+libInput);
		return dao.listLibrary(libInput);
	}

}
