package com.ssun.everybook.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ssun.everybook.domain.LibraryInput;
import com.ssun.everybook.domain.LibraryVO;

@Service
public interface LibraryService {

	public List<LibraryVO> listLibrary(LibraryInput libInput) throws Exception;
}
