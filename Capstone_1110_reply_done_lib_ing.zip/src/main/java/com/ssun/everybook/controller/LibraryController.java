package com.ssun.everybook.controller;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ssun.everybook.domain.LibraryInput;
import com.ssun.everybook.service.LibraryService;

@Controller
@RequestMapping("/bookbook/*")
public class LibraryController {

	private static final Logger logger = LoggerFactory.getLogger(LibraryController.class);

	@Inject
	private LibraryService service;

	/*
	 * // input 받아서 db에 넘겨주고 db 결과 값 가져와야됨. // 값으로 넘기기
	 * 
	 * @RequestMapping(value = "/library", method = RequestMethod.GET) public String
	 * getInput(HttpServletRequest request,
	 * 
	 * @RequestParam(value = "region", required = false, defaultValue = "") String
	 * region,
	 * 
	 * @RequestParam(value = "region2", required = false, defaultValue = "") String
	 * region2) throws Exception {
	 * 
	 * logger.
	 * info("@@@@@@@@@@@@@@@@@@@@@@@@@@@Library Controller@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"
	 * ); // 주소 System.out.println(region); // 상세주소 System.out.println(region2);
	 * 
	 * //service.listAll(); return "library"; }
	 */

	// input 받아서 db에 넘겨주고 db 결과 값 가져와야됨.
	// 객체로 넘기기
	@RequestMapping(value = "/library", method = RequestMethod.GET)
	public String getLibraryInput(LibraryInput libInput, Model model) throws Exception {

		logger.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@Library Controller@"
				+ libInput.toString());

		System.out.println(service.listLibrary(libInput) + "************************************");
		
		model.addAttribute("libInput", service.listLibrary(libInput));

		return "library";
	}

}
